import glob
import scipy as sp
from PIL import Image
import os, sys
from resizeimage import resizeimage

size = 100, 100
ite = 0
for file in glob.glob('./original/*.*'):
	a = open(file, 'rw')
	img = Image.open(a)
	#print file
	if img.width <= img.height:
		small = img.width
	else:
		small = img.height
	img = resizeimage.resize_crop(img, [small, small])
	img = img.resize((64, 64), Image.ANTIALIAS)
	out = "./output/" + str(ite) + ".jpeg"
	print out
	img.save(out, img.format)
	a.close()
	ite += 1
	